using System.Net;
using System.Net.NetworkInformation;
using System.Management;
using System.Net.Sockets;
using System.Diagnostics;

namespace FirstApp
{
    public partial class MainForm : Form
    {
        private System.Windows.Forms.Timer timer;
        public MainForm()
        {
            InitializeComponent();
            PopulateNetworkNames();

            button1.Click += button1_Click;
            button2.Click += button2_Click;
            button3.Click += buttonSettings_Click;

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 1000;
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();

        }

        private List<string> GetNetworkNames()
        {
            List<string> networkNames = new List<string>();
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT NetConnectionID FROM Win32_NetworkAdapter WHERE NetConnectionID IS NOT NULL");
            foreach (ManagementObject obj in searcher.Get())
            {
                string networkName = obj["NetConnectionID"].ToString();
                if (!string.IsNullOrEmpty(networkName))
                {
                    networkNames.Add(networkName);
                }
            }
            return networkNames;
        }

        private void PopulateNetworkNames()
        {
            // Clear the existing items in the ListBox
            listBox1.Items.Clear();

            // Get the list of network names
            List<string> networkNames = GetNetworkNames();

            // Add each network name to the ListBox
            foreach (string networkName in networkNames)
            {
                listBox1.Items.Add(networkName);
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            string networkName, ipAddress, subnetMask, defaultGateway, primaryDns, secondaryDns;
            string setIpAddress1, setSubnetMask1, setDefaultGateway1;
            string setIpAddress2, setSubnetMask2, setDefaultGateway2;
            networkName = Properties.Settings.Default.NetworkName;
            setIpAddress1 = Properties.Settings.Default.IpAddress1;
            setIpAddress2 = Properties.Settings.Default.IpAddress2;
            setSubnetMask1 = Properties.Settings.Default.SubnetMask1;
            setSubnetMask2 = Properties.Settings.Default.SubnetMask2;
            setDefaultGateway1 = Properties.Settings.Default.DefaultGateway1;
            setDefaultGateway2 = Properties.Settings.Default.DefaultGateway2;

            GetNetworkSettings(networkName, out ipAddress, out subnetMask, out defaultGateway, out primaryDns, out secondaryDns);
            label1.Text = $"IP �����: {ipAddress}";
            label2.Text = $"����� �������: {subnetMask}";
            label3.Text = $"�������� ����: {defaultGateway}";
            if (ipAddress == setIpAddress1 && subnetMask == setSubnetMask1 && defaultGateway == setDefaultGateway1)
            {
                label4.Text = $"������� �����������: {Properties.Settings.Default.Name1}";
            }
            else if (ipAddress == setIpAddress2 && subnetMask == setSubnetMask2 && defaultGateway == setDefaultGateway2)
            {
                label4.Text = $"������� �����������: {Properties.Settings.Default.Name2}";
            }
            label5.Text = $"�������� ����: {networkName}";
            label6.Text = $"DNS ������: {primaryDns}";
            label7.Text = $"�������������� DNS ������: {secondaryDns}";

        }

        private void button1_Click(object? sender, EventArgs e)
        {
            string networkName = Properties.Settings.Default.NetworkName;
            string ipAddress = Properties.Settings.Default.IpAddress1;
            string subnetMask = Properties.Settings.Default.SubnetMask1;
            string defaultGateway = Properties.Settings.Default.DefaultGateway1;
            string primaryDns = Properties.Settings.Default.PrimaryDns1;
            string secondaryDns = Properties.Settings.Default.SecondaryDns1;
            //ChangeIPAddress("Ethernet", ipAddress, subnetMask, defaultGateway);
            //ChangeIpAddress(networkName, ipAddress, subnetMask, defaultGateway);
            //string[] dnsServers = { primaryDns, secondaryDns };
            string dnsServers = primaryDns + " " + secondaryDns;
            //SetIP(networkName, ipAddress, subnetMask, defaultGateway, dnsServers);
            //SetupNIC("9C-2F-9D-4F-92-01", ipAddress, subnetMask, defaultGateway, primaryDns);
            SetIP33(networkName, ipAddress, subnetMask, defaultGateway, primaryDns);
            //SetNameServers(networkName, dnsServers);
        }


        private void button2_Click(object? sender, EventArgs e)
        {
            string networkName = Properties.Settings.Default.NetworkName;
            string ipAddress = Properties.Settings.Default.IpAddress2;
            string subnetMask = Properties.Settings.Default.SubnetMask2;
            string defaultGateway = Properties.Settings.Default.DefaultGateway2;
            string primaryDns = Properties.Settings.Default.PrimaryDns2;
            string secondaryDns = Properties.Settings.Default.SecondaryDns2;
            //ChangeIPAddress("Ethernet", ipAddress, subnetMask, defaultGateway);
            //ChangeIpAddress(networkName, ipAddress, subnetMask, defaultGateway);

            //string[] dnsServers = { primaryDns, secondaryDns };
            string dnsServers = primaryDns + " " + secondaryDns;
            //SetIP(networkName, ipAddress, subnetMask, defaultGateway, dnsServers);
            SetIP33(networkName, ipAddress, subnetMask, defaultGateway, primaryDns);
            //SetNameServers(networkName, dnsServers);
        }

        private void buttonSettings_Click(object? sender, EventArgs e)
        {
            SettingsForm settingsForm = new SettingsForm();

            DialogResult result = settingsForm.ShowDialog();
        }
        private void ChangeIpAddress(string networkName, string ipAddress, string subnetMask, string defaultGateway)
        {

        }

        public void SetIP(string ipAddress, string subnetMask, string gateway)
        {
            using (var networkConfigMng = new ManagementClass("Win32_NetworkAdapterConfiguration"))
            {
                using (var networkConfigs = networkConfigMng.GetInstances())
                {
                    foreach (var managementObject in networkConfigs.Cast<ManagementObject>().Where(managementObject => (bool)managementObject["IPEnabled"]))
                    {
                        using (var newIP = managementObject.GetMethodParameters("EnableStatic"))
                        {
                            if ((!String.IsNullOrEmpty(ipAddress)) || (!String.IsNullOrEmpty(subnetMask)))
                            {
                                if (!String.IsNullOrEmpty(ipAddress))
                                {
                                    newIP["IPAddress"] = new[] { ipAddress };
                                }

                                if (!String.IsNullOrEmpty(subnetMask))
                                {
                                    newIP["SubnetMask"] = new[] { subnetMask };
                                }

                                managementObject.InvokeMethod("EnableStatic", newIP, null);
                            }

                            if (!String.IsNullOrEmpty(gateway))
                            {
                                using (var newGateway = managementObject.GetMethodParameters("SetGateways"))
                                {
                                    newGateway["DefaultIPGateway"] = new[] { gateway };
                                    newGateway["GatewayCostMetric"] = new[] { 1 };
                                    managementObject.InvokeMethod("SetGateways", newGateway, null);
                                }
                            }
                        }
                    }
                }
            }
        }

        public void SetIP(string networkName, string ipAddress, string subnetMask, string defaultGateway)
        {
            using (var networkConfigMng = new ManagementClass("Win32_NetworkAdapterConfiguration"))
            {
                using (var networkConfigs = networkConfigMng.GetInstances())
                {
                    foreach (var managementObject in networkConfigs.Cast<ManagementObject>().Where(managementObject => (bool)managementObject["IPEnabled"] && managementObject["Caption"].ToString().Contains(networkName)))
                    {
                        using (var newIP = managementObject.GetMethodParameters("EnableStatic"))
                        {
                            if ((!String.IsNullOrEmpty(ipAddress)) || (!String.IsNullOrEmpty(subnetMask)))
                            {
                                if (!String.IsNullOrEmpty(ipAddress))
                                {
                                    newIP["IPAddress"] = new[] { ipAddress };
                                }

                                if (!String.IsNullOrEmpty(subnetMask))
                                {
                                    newIP["SubnetMask"] = new[] { subnetMask };
                                }

                                managementObject.InvokeMethod("EnableStatic", newIP, null);
                            }

                            if (!String.IsNullOrEmpty(defaultGateway))
                            {
                                using (var newGateway = managementObject.GetMethodParameters("SetGateways"))
                                {
                                    newGateway["DefaultIPGateway"] = new[] { defaultGateway };
                                    newGateway["GatewayCostMetric"] = new[] { 1 };
                                    managementObject.InvokeMethod("SetGateways", newGateway, null);
                                }
                            }
                        }
                    }
                }
            }
        }

        public void SetIP(string networkName, string ipAddress, string subnetMask, string defaultGateway, string primaryDNS, string secondaryDNS)
        {
            using (var networkConfigMng = new ManagementClass("Win32_NetworkAdapterConfiguration"))
            {
                using (var networkConfigs = networkConfigMng.GetInstances())
                {
                    foreach (var managementObject in networkConfigs.Cast<ManagementObject>().Where(managementObject => (bool)managementObject["IPEnabled"] && managementObject["Caption"].ToString().Contains(networkName)))
                    {
                        using (var newIP = managementObject.GetMethodParameters("EnableStatic"))
                        {
                            if ((!String.IsNullOrEmpty(ipAddress)) || (!String.IsNullOrEmpty(subnetMask)))
                            {
                                if (!String.IsNullOrEmpty(ipAddress))
                                {
                                    newIP["IPAddress"] = new[] { ipAddress };
                                }

                                if (!String.IsNullOrEmpty(subnetMask))
                                {
                                    newIP["SubnetMask"] = new[] { subnetMask };
                                }

                                managementObject.InvokeMethod("EnableStatic", newIP, null);
                            }

                            if (!String.IsNullOrEmpty(defaultGateway))
                            {
                                using (var newGateway = managementObject.GetMethodParameters("SetGateways"))
                                {
                                    newGateway["DefaultIPGateway"] = new[] { defaultGateway };
                                    newGateway["GatewayCostMetric"] = new[] { 1 };
                                    managementObject.InvokeMethod("SetGateways", newGateway, null);
                                }
                            }

                            if (!String.IsNullOrEmpty(primaryDNS) || !String.IsNullOrEmpty(secondaryDNS))
                            {
                                using (var newDNS = managementObject.GetMethodParameters("SetDNSServerSearchOrder"))
                                {
                                    var dnsList = new List<string>();

                                    if (!String.IsNullOrEmpty(primaryDNS))
                                    {
                                        dnsList.Add(primaryDNS);
                                    }

                                    if (!String.IsNullOrEmpty(secondaryDNS))
                                    {
                                        dnsList.Add(secondaryDNS);
                                    }

                                    newDNS["DNSServerSearchOrder"] = dnsList.ToArray();
                                    managementObject.InvokeMethod("SetDNSServerSearchOrder", newDNS, null);
                                }
                            }
                        }
                    }
                }
            }
        }

        public bool SetIP33(string networkInterfaceName, string ipAddress, string subnetMask, string gateway = null)
        {
            var networkInterface = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(nw => nw.Name == networkInterfaceName);
            var ipProperties = networkInterface.GetIPProperties();
            var ipInfo = ipProperties.UnicastAddresses.FirstOrDefault(ip => ip.Address.AddressFamily == AddressFamily.InterNetwork);
            var currentIPaddress = ipInfo.Address.ToString();
            var currentSubnetMask = ipInfo.IPv4Mask.ToString();
            var isDHCPenabled = ipProperties.GetIPv4Properties().IsDhcpEnabled;

            if (!isDHCPenabled && currentIPaddress == ipAddress && currentSubnetMask == subnetMask)
                return true;    // no change necessary

            var process = new Process
            {
                StartInfo = new ProcessStartInfo("netsh", $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask} {gateway}")
                {
                    Verb = "runas"
                }
            };
            //StartInfo = new ProcessStartInfo("netsh", $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask}" + (string.IsNullOrWhiteSpace(gateway) ? "" : $"{gateway} 1")) { Verb = "runas" }
            //};
            process.Start();
            process.WaitForExit();
            var successful = process.ExitCode == 0;
            process.Dispose();
            return successful;
        }
        public bool SetIP33(string networkInterfaceName, string ipAddress, string subnetMask, string gateway, string primaryDns)
        {
            var networkInterface = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(nw => nw.Name == networkInterfaceName);
            var ipProperties = networkInterface.GetIPProperties();
            var ipInfo = ipProperties.UnicastAddresses.FirstOrDefault(ip => ip.Address.AddressFamily == AddressFamily.InterNetwork);
            var currentIPaddress = ipInfo.Address.ToString();
            var currentSubnetMask = ipInfo.IPv4Mask.ToString();
            var isDHCPenabled = ipProperties.GetIPv4Properties().IsDhcpEnabled;

            if (!isDHCPenabled && currentIPaddress == ipAddress && currentSubnetMask == subnetMask)
                return true;    // no change necessary

            var process = new Process
            {
                StartInfo = new ProcessStartInfo("netsh", $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask} {gateway}")
                {
                    Verb = "runas"
                }
            };
            //StartInfo = new ProcessStartInfo("netsh", $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask}" + (string.IsNullOrWhiteSpace(gateway) ? "" : $"{gateway} 1")) { Verb = "runas" }
            //};
            process.Start();
            process.WaitForExit();
            var successful = process.ExitCode == 0;
            process.Dispose();
            var process2 = new Process
            {
                StartInfo = new ProcessStartInfo("netsh", $"interface ip set dns \"{networkInterfaceName}\" static {primaryDns}")
                {
                    Verb = "runas"
                }
            };
            //StartInfo = new ProcessStartInfo("netsh", $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask}" + (string.IsNullOrWhiteSpace(gateway) ? "" : $"{gateway} 1")) { Verb = "runas" }
            //};
            process2.Start();
            process2.WaitForExit();
            var successful2 = process2.ExitCode == 0;
            process2.Dispose();
            return successful;
        }

        public bool SetIP3(string networkInterfaceName, string ipAddress, string subnetMask, string gateway = null, string dnsServer = null)
        {
            var networkInterface = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(nw => nw.Name == networkInterfaceName);
            var ipProperties = networkInterface.GetIPProperties();
            var ipInfo = ipProperties.UnicastAddresses.FirstOrDefault(ip => ip.Address.AddressFamily == AddressFamily.InterNetwork);
            var currentIPaddress = ipInfo.Address.ToString();
            var currentSubnetMask = ipInfo.IPv4Mask.ToString();
            var isDHCPenabled = ipProperties.GetIPv4Properties().IsDhcpEnabled;

            if (!isDHCPenabled && currentIPaddress == ipAddress && currentSubnetMask == subnetMask)
                return true;    // no change necessary

            var command = $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask}" + (string.IsNullOrWhiteSpace(gateway) ? "" : $" {gateway} 1");
            if (!string.IsNullOrWhiteSpace(dnsServer))
            {
                command += $" && interface ip set dns \"{networkInterfaceName}\" static {dnsServer}";
            }

            var process = new Process
            {
                StartInfo = new ProcessStartInfo("netsh", command) { Verb = "runas" }
            };
            process.Start();
            process.WaitForExit(); // Wait for the process to exit
            var successful = process.HasExited && process.ExitCode == 0; // Check if the process has exited and the exit code is 0
            process.Dispose();
            return successful;
        }

        public void SetIP(string networkName, string ipAddress, string subnetMask, string defaultGateway, string[] dnsServers)
        {
            using (var networkConfigMng = new ManagementClass("Win32_NetworkAdapterConfiguration"))
            {
                using (var networkConfigs = networkConfigMng.GetInstances())
                {
                    foreach (var managementObject in networkConfigs.Cast<ManagementObject>().Where(managementObject => (bool)managementObject["IPEnabled"] && managementObject["Caption"].ToString().Contains(networkName)))
                    {
                        using (var newIP = managementObject.GetMethodParameters("EnableStatic"))
                        {
                            if ((!String.IsNullOrEmpty(ipAddress)) || (!String.IsNullOrEmpty(subnetMask)))
                            {
                                if (!String.IsNullOrEmpty(ipAddress))
                                {
                                    newIP["IPAddress"] = new[] { ipAddress };
                                }

                                if (!String.IsNullOrEmpty(subnetMask))
                                {
                                    newIP["SubnetMask"] = new[] { subnetMask };
                                }

                                managementObject.InvokeMethod("EnableStatic", newIP, null);
                            }

                            if (!String.IsNullOrEmpty(defaultGateway))
                            {
                                using (var newGateway = managementObject.GetMethodParameters("SetGateways"))
                                {
                                    newGateway["DefaultIPGateway"] = new[] { defaultGateway };
                                    newGateway["GatewayCostMetric"] = new[] { 1 };
                                    managementObject.InvokeMethod("SetGateways", newGateway, null);
                                }
                            }

                            if (dnsServers != null && dnsServers.Length > 0)
                            {
                                using (var newDNS = managementObject.GetMethodParameters("SetDNSServerSearchOrder"))
                                {
                                    newDNS["DNSServerSearchOrder"] = dnsServers;
                                    managementObject.InvokeMethod("SetDNSServerSearchOrder", newDNS, null);
                                }
                            }
                        }
                    }
                }
            }
        }
        static NetworkInterface GetNetworkInterface(string macAddress)
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (macAddress == ni.GetPhysicalAddress().ToString())
                    return ni;
            }
            return null;
        }
        static ManagementObject GetNetworkInterfaceManagementObject(string macAddress)
        {
            NetworkInterface ni = GetNetworkInterface(macAddress);
            if (ni == null)
                return null;
            ManagementClass managementClass = new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObjectCollection moc = managementClass.GetInstances();
            foreach (ManagementObject mo in moc)
            {
                if (mo["settingID"].ToString() == ni.Id)
                    return mo;
            }
            return null;
        }

        public bool SetIP2(string networkInterfaceName, string ipAddress, string subnetMask, string gateway = null)
        {
            var networkInterface = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(nw => nw.Name == networkInterfaceName);
            var ipProperties = networkInterface.GetIPProperties();
            var ipInfo = ipProperties.UnicastAddresses.FirstOrDefault(ip => ip.Address.AddressFamily == AddressFamily.InterNetwork);
            var currentIPaddress = ipInfo.Address.ToString();
            var currentSubnetMask = ipInfo.IPv4Mask.ToString();
            var isDHCPenabled = ipProperties.GetIPv4Properties().IsDhcpEnabled;

            if (!isDHCPenabled && currentIPaddress == ipAddress && currentSubnetMask == subnetMask)
                return true;    // no change necessary

            var process = new Process
            {
                StartInfo = new ProcessStartInfo("netsh", $"interface ip set address \"{networkInterfaceName}\" static {ipAddress} {subnetMask}" + (string.IsNullOrWhiteSpace(gateway) ? "" : $"{gateway} 1")) { Verb = "runas" }
            };
            process.Start();
            var successful = process.ExitCode == 0;
            process.Dispose();
            return successful;
        }
        static bool SetupNIC(string macAddress, string ip, string subnet, string gateway, string dns)
        {
            try
            {
                ManagementObject mo = GetNetworkInterfaceManagementObject(macAddress);

                //Set IP
                ManagementBaseObject mboIP = mo.GetMethodParameters("EnableStatic");
                mboIP["IPAddress"] = new string[] { ip };
                mboIP["SubnetMask"] = new string[] { subnet };
                mo.InvokeMethod("EnableStatic", mboIP, null);

                //Set Gateway
                ManagementBaseObject mboGateway = mo.GetMethodParameters("SetGateways");
                mboGateway["DefaultIPGateway"] = new string[] { gateway };
                mboGateway["GatewayCostMetric"] = new int[] { 1 };
                mo.InvokeMethod("SetGateways", mboGateway, null);

                //Set DNS
                ManagementBaseObject mboDNS = mo.GetMethodParameters("SetDNSServerSearchOrder");
                mboDNS["DNSServerSearchOrder"] = new string[] { dns };
                mo.InvokeMethod("SetDNSServerSearchOrder", mboDNS, null);

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        /*public static void SetNameServers(string nicDescription, string[] dnsServers)
        {
            using (var networkConfigMng = new ManagementClass("Win32_NetworkAdapterConfiguration"))
            {
                using (var networkConfigs = networkConfigMng.GetInstances())
                {
                    foreach (var managementObject in networkConfigs.Cast<ManagementObject>().Where(mo => (bool)mo["IPEnabled"] && (string)mo["Description"] == nicDescription))
                    {
                        using (var newDNS = managementObject.GetMethodParameters("SetDNSServerSearchOrder"))
                        {
                            newDNS["DNSServerSearchOrder"] = dnsServers;
                            managementObject.InvokeMethod("SetDNSServerSearchOrder", newDNS, null);
                        }
                    }
                }
            }
        }*/

        private void GetNetworkSettings(string networkName, out string ipAddress, out string subnetMask, out string defaultGateway, out string primaryDns, out string secondaryDns)
        {
            ipAddress = "";
            subnetMask = "";
            defaultGateway = "";
            primaryDns = "";
            secondaryDns = "";

            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface ni in interfaces)
            {
                // Check if the network name matches
                if (ni.Name == networkName)
                {
                    IPInterfaceProperties ipProps = ni.GetIPProperties();

                    foreach (UnicastIPAddressInformation ip in ipProps.UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            ipAddress = ip.Address.ToString();
                            subnetMask = ip.IPv4Mask.ToString();
                            break;
                        }
                    }

                    foreach (GatewayIPAddressInformation gw in ipProps.GatewayAddresses)
                    {
                        if (gw.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            defaultGateway = gw.Address.ToString();
                            break;
                        }
                    }

                    foreach (IPAddress dns in ipProps.DnsAddresses)
                    {
                        if (dns.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            if (string.IsNullOrEmpty(primaryDns))
                            {
                                primaryDns = dns.ToString();
                            }
                            else
                            {
                                secondaryDns = dns.ToString();
                                break;
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(ipAddress) && !string.IsNullOrEmpty(subnetMask) && !string.IsNullOrEmpty(defaultGateway))
                    {
                        break;
                    }
                }
            }
        }

        private void GetNetworkSettings(string networkName, out string ipAddress, out string subnetMask, out string defaultGateway)
        {
            ipAddress = "";
            subnetMask = "";
            defaultGateway = "";

            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface ni in interfaces)
            {
                // Check if the network name matches
                if (ni.Name == networkName)
                {
                    IPInterfaceProperties ipProps = ni.GetIPProperties();

                    foreach (UnicastIPAddressInformation ip in ipProps.UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            ipAddress = ip.Address.ToString();
                            subnetMask = ip.IPv4Mask.ToString();
                            break;
                        }
                    }

                    foreach (GatewayIPAddressInformation gw in ipProps.GatewayAddresses)
                    {
                        if (gw.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            defaultGateway = gw.Address.ToString();
                            break;
                        }
                    }

                    if (!string.IsNullOrEmpty(ipAddress) && !string.IsNullOrEmpty(subnetMask) && !string.IsNullOrEmpty(defaultGateway))
                    {
                        break;
                    }
                }
            }
        }
    }
}

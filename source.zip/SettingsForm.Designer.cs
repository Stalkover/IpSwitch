﻿namespace FirstApp
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            labelNameInput1 = new TextBox();
            label5 = new Label();
            label6 = new Label();
            labelNameInput2 = new TextBox();
            ipInput2 = new TextBox();
            subnetMaskInput1 = new TextBox();
            subnetMaskInput2 = new TextBox();
            gatewayInput1 = new TextBox();
            gatewayInput2 = new TextBox();
            button1 = new Button();
            ipInput1 = new TextBox();
            networkNameInput = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            dnsInput1 = new TextBox();
            dnsInput2 = new TextBox();
            secDnsInput1 = new TextBox();
            secDnsInput2 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 45);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 0;
            label1.Text = "Название:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 70);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 1;
            label2.Text = "IP адрес:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 95);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(92, 15);
            label3.TabIndex = 2;
            label3.Text = "Маска подсети:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 120);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(102, 15);
            label4.TabIndex = 3;
            label4.Text = "Основной шлюз:";
            // 
            // labelNameInput1
            // 
            labelNameInput1.Location = new Point(141, 40);
            labelNameInput1.Margin = new Padding(2);
            labelNameInput1.Name = "labelNameInput1";
            labelNameInput1.Size = new Size(106, 23);
            labelNameInput1.TabIndex = 4;
            labelNameInput1.Text = Properties.Settings.Default.Name1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(141, 22);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(52, 15);
            label5.TabIndex = 5;
            label5.Text = "Опция 1";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(295, 22);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(52, 15);
            label6.TabIndex = 6;
            label6.Text = "Опция 2";
            // 
            // labelNameInput2
            // 
            labelNameInput2.Location = new Point(295, 40);
            labelNameInput2.Margin = new Padding(2);
            labelNameInput2.Name = "labelNameInput2";
            labelNameInput2.Size = new Size(106, 23);
            labelNameInput2.TabIndex = 7;
            labelNameInput2.Text = Properties.Settings.Default.Name2;
            // 
            // ipInput2
            // 
            ipInput2.Location = new Point(295, 65);
            ipInput2.Margin = new Padding(2);
            ipInput2.Name = "ipInput2";
            ipInput2.Size = new Size(106, 23);
            ipInput2.TabIndex = 9;
            ipInput2.Text = Properties.Settings.Default.IpAddress2;
            // 
            // subnetMaskInput1
            // 
            subnetMaskInput1.Location = new Point(141, 90);
            subnetMaskInput1.Margin = new Padding(2);
            subnetMaskInput1.Name = "subnetMaskInput1";
            subnetMaskInput1.Size = new Size(106, 23);
            subnetMaskInput1.TabIndex = 10;
            subnetMaskInput1.Text = Properties.Settings.Default.SubnetMask1;
            // 
            // subnetMaskInput2
            // 
            subnetMaskInput2.Location = new Point(295, 90);
            subnetMaskInput2.Margin = new Padding(2);
            subnetMaskInput2.Name = "subnetMaskInput2";
            subnetMaskInput2.Size = new Size(106, 23);
            subnetMaskInput2.TabIndex = 11;
            subnetMaskInput2.Text = Properties.Settings.Default.SubnetMask2;
            // 
            // gatewayInput1
            // 
            gatewayInput1.Location = new Point(141, 115);
            gatewayInput1.Margin = new Padding(2);
            gatewayInput1.Name = "gatewayInput1";
            gatewayInput1.Size = new Size(106, 23);
            gatewayInput1.TabIndex = 12;
            gatewayInput1.Text = Properties.Settings.Default.DefaultGateway1;
            // 
            // gatewayInput2
            // 
            gatewayInput2.Location = new Point(295, 115);
            gatewayInput2.Margin = new Padding(2);
            gatewayInput2.Name = "gatewayInput2";
            gatewayInput2.Size = new Size(106, 23);
            gatewayInput2.TabIndex = 13;
            gatewayInput2.Text = Properties.Settings.Default.DefaultGateway2;
            // 
            // button1
            // 
            button1.Location = new Point(207, 290);
            button1.Margin = new Padding(2);
            button1.Name = "button1";
            button1.Size = new Size(78, 20);
            button1.TabIndex = 14;
            button1.Text = "OK";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // ipInput1
            // 
            ipInput1.Location = new Point(141, 65);
            ipInput1.Name = "ipInput1";
            ipInput1.Size = new Size(106, 23);
            ipInput1.TabIndex = 15;
            ipInput1.Text = Properties.Settings.Default.IpAddress1;
            // 
            // networkNameInput
            // 
            networkNameInput.Location = new Point(141, 230);
            networkNameInput.Margin = new Padding(2);
            networkNameInput.Name = "networkNameInput";
            networkNameInput.Size = new Size(154, 23);
            networkNameInput.TabIndex = 16;
            networkNameInput.Text = Properties.Settings.Default.NetworkName;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 235);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(89, 15);
            label7.TabIndex = 17;
            label7.Text = "Название сети:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(16, 145);
            label8.Name = "label8";
            label8.Size = new Size(74, 15);
            label8.TabIndex = 18;
            label8.Text = "DNS сервер:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(16, 170);
            label9.Name = "label9";
            label9.Size = new Size(83, 15);
            label9.TabIndex = 19;
            label9.Text = "DNS сервер 2:";
            // 
            // dnsInput1
            // 
            dnsInput1.Location = new Point(141, 140);
            dnsInput1.Name = "dnsInput1";
            dnsInput1.Size = new Size(106, 23);
            dnsInput1.TabIndex = 20;
            dnsInput1.Text = Properties.Settings.Default.PrimaryDns1;
            // 
            // dnsInput2
            // 
            dnsInput2.Location = new Point(295, 140);
            dnsInput2.Name = "dnsInput2";
            dnsInput2.Size = new Size(106, 23);
            dnsInput2.TabIndex = 21;
            dnsInput2.Text = Properties.Settings.Default.PrimaryDns2;
            // 
            // secDnsInput1
            // 
            secDnsInput1.Location = new Point(141, 165);
            secDnsInput1.Name = "secDnsInput1";
            secDnsInput1.Size = new Size(106, 23);
            secDnsInput1.TabIndex = 22;
            secDnsInput1.Text = Properties.Settings.Default.SecondaryDns1;
            // 
            // secDnsInput2
            // 
            secDnsInput2.Location = new Point(295, 165);
            secDnsInput2.Name = "secDnsInput2";
            secDnsInput2.Size = new Size(106, 23);
            secDnsInput2.TabIndex = 23;
            secDnsInput2.Text = Properties.Settings.Default.SecondaryDns2;
            // 
            // SettingsForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(481, 352);
            Controls.Add(secDnsInput2);
            Controls.Add(secDnsInput1);
            Controls.Add(dnsInput2);
            Controls.Add(dnsInput1);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(networkNameInput);
            Controls.Add(ipInput1);
            Controls.Add(button1);
            Controls.Add(gatewayInput2);
            Controls.Add(gatewayInput1);
            Controls.Add(subnetMaskInput2);
            Controls.Add(subnetMaskInput1);
            Controls.Add(ipInput2);
            Controls.Add(labelNameInput2);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(labelNameInput1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(2);
            Name = "SettingsForm";
            Text = "Параметры";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox labelNameInput1;
        private Label label5;
        private Label label6;
        private TextBox labelNameInput2;
        private TextBox ipInput2;
        private TextBox subnetMaskInput1;
        private TextBox subnetMaskInput2;
        private TextBox gatewayInput1;
        private TextBox gatewayInput2;
        private Button button1;
        private TextBox textBox1;
        private TextBox ipInput1;
        private TextBox networkNameInput;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox dnsInput1;
        private TextBox dnsInput2;
        private TextBox secDnsInput1;
        private TextBox secDnsInput2;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstApp
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
            button1.Click += button1_Click;
        }

        private void button1_Click(object? sender, EventArgs e)
        {
            Properties.Settings.Default.Name1 = labelNameInput1.Text;
            Properties.Settings.Default.Name2 = labelNameInput2.Text;
            Properties.Settings.Default.IpAddress1 = ipInput1.Text;
            Properties.Settings.Default.IpAddress2 = ipInput2.Text;
            Properties.Settings.Default.SubnetMask1 = subnetMaskInput1.Text;
            Properties.Settings.Default.SubnetMask2 = subnetMaskInput2.Text;
            Properties.Settings.Default.DefaultGateway1 = gatewayInput1.Text;
            Properties.Settings.Default.DefaultGateway2 = gatewayInput2.Text;
            Properties.Settings.Default.PrimaryDns1 = dnsInput1.Text;
            Properties.Settings.Default.PrimaryDns2 = dnsInput2.Text;
            Properties.Settings.Default.SecondaryDns1 = secDnsInput1.Text;
            Properties.Settings.Default.SecondaryDns2 = secDnsInput2.Text;
            Properties.Settings.Default.NetworkName = networkNameInput.Text;
            Properties.Settings.Default.Save();
            this.Close();
        }
    }
}
